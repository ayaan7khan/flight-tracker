import React, { useState, useRef, useEffect } from 'react';
import { Plane, Send, Loader2, PlaneLanding, PlaneTakeoff, Info } from 'lucide-react';
import { format } from 'date-fns';
import { searchFlight } from './services/flightApi';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  flightData?: any;
}

interface Flight {
  flight_number: string;
  departure: {
    airport: string;
    scheduled: string;
    actual?: string;
    terminal?: string;
    gate?: string;
  };
  arrival: {
    airport: string;
    scheduled: string;
    actual?: string;
    terminal?: string;
    gate?: string;
  };
  airline: {
    name: string;
  };
  status: string;
}

function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm your AI Flight Assistant. I can help you track flights, check schedules, and provide real-time updates. Try asking me about a flight number (e.g., AA123, UA456)!",
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const flightData = await searchFlight(input);
      
      let responseText = '';
      if (flightData) {
        responseText = `I found flight ${flightData.flight_number} operated by ${flightData.airline.name}:\n\n` +
          `Departure: ${flightData.departure.airport} at ${format(new Date(flightData.departure.scheduled), 'PPpp')}\n` +
          `Terminal: ${flightData.departure.terminal || 'N/A'}, Gate: ${flightData.departure.gate || 'N/A'}\n\n` +
          `Arrival: ${flightData.arrival.airport} at ${format(new Date(flightData.arrival.scheduled), 'PPpp')}\n` +
          `Terminal: ${flightData.arrival.terminal || 'N/A'}, Gate: ${flightData.arrival.gate || 'N/A'}\n\n` +
          `Status: ${flightData.status.toUpperCase()}`;
      } else {
        responseText = "I couldn't find any information for that flight. Please check the flight number and try again. Example flight numbers: AA123, UA456, DL789";
      }

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: responseText,
        sender: 'bot',
        timestamp: new Date(),
        flightData,
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "Sorry, I encountered an error while fetching flight information. Please try again later.",
        sender: 'bot',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-blue-950">
      <div className="max-w-4xl mx-auto p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 bg-blue-800/50 p-4 rounded-lg backdrop-blur-sm">
          <div className="flex items-center space-x-3">
            <Plane className="h-8 w-8 text-blue-400" />
            <h1 className="text-2xl font-bold text-white">AI Flight Assistant</h1>
          </div>
          <div className="flex items-center space-x-2 text-blue-200 text-sm">
            <Info className="h-4 w-4" />
            <span>Real-time flight tracking</span>
          </div>
        </div>

        {/* Chat Container */}
        <div className="bg-blue-800/30 rounded-lg backdrop-blur-sm shadow-xl">
          {/* Messages */}
          <div className="h-[600px] overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-4 ${
                    message.sender === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-blue-800/50 text-blue-100'
                  }`}
                >
                  {message.flightData ? (
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <PlaneTakeoff className="h-5 w-5 text-blue-300" />
                        <div>
                          <p className="font-semibold">{message.flightData.departure.airport}</p>
                          <p className="text-sm text-blue-300">
                            {format(new Date(message.flightData.departure.scheduled), 'PPpp')}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <PlaneLanding className="h-5 w-5 text-blue-300" />
                        <div>
                          <p className="font-semibold">{message.flightData.arrival.airport}</p>
                          <p className="text-sm text-blue-300">
                            {format(new Date(message.flightData.arrival.scheduled), 'PPpp')}
                          </p>
                        </div>
                      </div>
                      <div className="mt-2 pt-2 border-t border-blue-700">
                        <p className="text-sm">
                          Flight {message.flightData.flight_number} • {message.flightData.airline.name}
                        </p>
                        <p className="text-sm text-blue-300">
                          Status: {message.flightData.status.toUpperCase()}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <p className="whitespace-pre-line">{message.text}</p>
                  )}
                  <div className="mt-2 text-xs text-blue-300">
                    {format(message.timestamp, 'p')}
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Form */}
          <form onSubmit={handleSubmit} className="p-4 border-t border-blue-700">
            <div className="flex space-x-4">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Enter flight number (e.g., AA123)..."
                className="flex-1 bg-blue-900/50 text-white placeholder-blue-400 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={isLoading}
                className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-6 py-2 flex items-center space-x-2 transition-colors disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <Send className="h-5 w-5" />
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default App;