import axios from 'axios';

const AVIATION_API_KEY = import.meta.env.VITE_AVIATION_API_KEY;
const BASE_URL = 'http://api.aviationstack.com/v1';

interface FlightApiResponse {
  data: Array<{
    flight: {
      iata: string;
    };
    departure: {
      airport: string;
      scheduled: string;
      terminal: string;
      gate: string;
    };
    arrival: {
      airport: string;
      scheduled: string;
      terminal: string;
      gate: string;
    };
    airline: {
      name: string;
    };
    flight_status: string;
  }>;
}

export const searchFlight = async (query: string) => {
  try {
    const response = await axios.get<FlightApiResponse>(`${BASE_URL}/flights`, {
      params: {
        access_key: AVIATION_API_KEY,
        flight_iata: query.toUpperCase(),
      },
    });

    if (response.data.data.length === 0) {
      return null;
    }

    const flight = response.data.data[0];
    return {
      flight_number: flight.flight.iata,
      departure: {
        airport: flight.departure.airport,
        scheduled: flight.departure.scheduled,
        terminal: flight.departure.terminal,
        gate: flight.departure.gate,
      },
      arrival: {
        airport: flight.arrival.airport,
        scheduled: flight.arrival.scheduled,
        terminal: flight.arrival.terminal,
        gate: flight.arrival.gate,
      },
      airline: {
        name: flight.airline.name,
      },
      status: flight.flight_status,
    };
  } catch (error) {
    console.error('Error fetching flight data:', error);
    throw new Error('Failed to fetch flight data');
  }
};