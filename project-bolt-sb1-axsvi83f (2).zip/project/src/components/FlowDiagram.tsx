import React from 'react';
import ReactFlow, { 
  Node, 
  Edge,
  Background,
  Controls,
  MiniMap,
  Position
} from 'reactflow';
import 'reactflow/dist/style.css';

const nodes: Node[] = [
  {
    id: '1',
    type: 'input',
    data: { label: 'Process Creation' },
    position: { x: 250, y: 0 },
    style: {
      background: '#2563eb',
      color: 'white',
      border: 'none',
      borderRadius: '8px',
      padding: '10px',
      width: 180,
    },
  },
  {
    id: '2',
    data: { label: 'Process Scheduling' },
    position: { x: 250, y: 100 },
    style: {
      background: '#4f46e5',
      color: 'white',
      border: 'none',
      borderRadius: '8px',
      padding: '10px',
      width: 180,
    },
  },
  {
    id: '3',
    data: { label: 'CPU Execution' },
    position: { x: 250, y: 200 },
    style: {
      background: '#7c3aed',
      color: 'white',
      border: 'none',
      borderRadius: '8px',
      padding: '10px',
      width: 180,
    },
  },
  {
    id: '4',
    data: { label: 'Memory Management' },
    position: { x: 500, y: 100 },
    style: {
      background: '#6366f1',
      color: 'white',
      border: 'none',
      borderRadius: '8px',
      padding: '10px',
      width: 180,
    },
  },
  {
    id: '5',
    data: { label: 'Process Termination' },
    position: { x: 250, y: 300 },
    style: {
      background: '#8b5cf6',
      color: 'white',
      border: 'none',
      borderRadius: '8px',
      padding: '10px',
      width: 180,
    },
  },
  {
    id: '6',
    data: { label: 'Resource Allocation' },
    position: { x: 0, y: 100 },
    style: {
      background: '#6366f1',
      color: 'white',
      border: 'none',
      borderRadius: '8px',
      padding: '10px',
      width: 180,
    },
  },
];

const edges: Edge[] = [
  { id: 'e1-2', source: '1', target: '2', animated: true },
  { id: 'e2-3', source: '2', target: '3', animated: true },
  { id: 'e3-5', source: '3', target: '5', animated: true },
  { id: 'e2-4', source: '2', target: '4', type: 'step', animated: true },
  { id: 'e4-3', source: '4', target: '3', type: 'step', animated: true },
  { id: 'e2-6', source: '2', target: '6', type: 'step', animated: true },
  { id: 'e6-3', source: '6', target: '3', type: 'step', animated: true },
];

const FlowDiagram: React.FC = () => {
  return (
    <div className="w-full h-[600px] bg-blue-900/30 rounded-lg overflow-hidden">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        fitView
        attributionPosition="bottom-right"
      >
        <Background color="#334155" gap={16} />
        <Controls />
        <MiniMap 
          nodeColor={(node) => {
            switch (node.id) {
              case '1':
                return '#2563eb';
              case '2':
                return '#4f46e5';
              case '3':
                return '#7c3aed';
              case '4':
                return '#6366f1';
              case '5':
                return '#8b5cf6';
              case '6':
                return '#6366f1';
              default:
                return '#fff';
            }
          }}
          maskColor="rgba(0, 0, 0, 0.2)"
        />
      </ReactFlow>
    </div>
  );
};

export default FlowDiagram;